import Navbar from '../components/navbar'
function UsersDetails()
{


    return(
        <div>
            
            <Navbar/>
            <h1 className="page-header">UsersDetails</h1>
        </div>
    )
}
export default UsersDetails