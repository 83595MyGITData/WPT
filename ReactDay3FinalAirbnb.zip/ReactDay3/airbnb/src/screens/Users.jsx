import Navbar from "../components/navbar"
import usersData from '../dummy/users.json'
import { useState,useEffect } from 'react'
import { getUsers } from "../services/admin"
function Users()
{
    const [users, setUsers] = useState(usersData)

    const loadUsers=async()=>{

        const result=await getUsers ()
        if(result.status=='success')
            { debugger
                setUsers(result.data)
                console.log(result)
            }
        else{
            alert(result.error)
        }
    }

    useEffect(() => {
        loadUsers()
    },[])
    return(
        <div>
            <Navbar/>
            
            <h1 className="page-header">Users</h1>
            {users &&(
            <div className="table table-stripped">
                
                <thead>
                    <tr>
                        <th>#</th>
                        <th>firstName</th>
                        <th>lastName</th>
                        <th>Email</th>
                        <th>Phone</th>
                    
                        <th>Actions</th>
                    </tr>

                </thead>
                <tbody>
                    {users.map ((user,index)=>{
                        return(
                            <tr>
                                <td>{index + 1}</td>
                <td>
                  {user['firstName']}
                </td>
                <td>{user['lastName']}</td>
                <td>{user['email']}</td>
                <td>{user['phone']}</td>
                <td>
                  <button className='btn btn-sm btn-success me-2'>
                    Deactivate
                  </button>
                  <button className='btn btn-sm btn-primary'>Details</button>
                </td>
              
                            </tr>
                        )
                    })}
                </tbody>
            </div>
            )}
        
        </div>
    )
}
export default Users