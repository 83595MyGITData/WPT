import { Link, useLocation, useNavigate } from 'react-router-dom'
import Navbar from '../components/navbar'
//import propertiesData from '../dummy/properties.json'
import { useEffect,useState } from 'react'
import { deleteProperty, getProperties } from '../services/property'


function Properties()
{

    const location=useLocation()
    const navigate = useNavigate()
    const[properties,setProperties]=useState([])
    const loadProperties = async () => {

        const result = await getProperties()
        if (result['status'] == 'success') {
          setProperties(result['data'])
        }
        else{
            console.log(result['error'])
        }
      }
    
      useEffect(() => {
       // this function will be called immediately after component gets loaded
        loadProperties()
      }, [])
    
    const onDelete =  (index)=>{
        properties.splice(index,1)
        // const result= await deleteProperty ({ state: { id: properties[index].id } })
        // if(result.status=='success')
        // {
        //     loadProperties()
        // }
        //navigate('/property-details-edit', { state: { id: properties[index].id } })
        setProperties([...properties])
    }
    const onUpdate =(index)=>{
        //navigate('/property-details-edit', { state: { id: properties[index].id } })
        console.log("Index :"+ properties[index].id);
    }
    const onDetails =(index)=>{
        navigate('/property-details', { state: { id: properties[index].id } })
        console.log("Index :"+ properties[index].id);
    }
    return(
        <div>
            <Navbar />
            <h1>Properties</h1>
            <div className="mb-3 mt-3">
                <Link to ="/addProperty" className="btn btn-success">Add Property</Link>
            </div>
            <table className="table table-striped mt-5">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Address</th>
                    <th>Rent</th>
                    <th>ContactNumber</th>
                    <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        properties.map((property,index)=>{
                            return(
                            <tr>
                                <td>{index + 1 }</td>
                                <td>{property.title}</td>
                                <td>{property.address}</td>
                                <td>{property.rent}</td>
                                <td>{property.contactNo}</td>
                                                               {/* <td>{property.city}</td>
                                <td>{property.state}</td>
                                <td>{property.zipCode}</td>
                                <td> */}<td>
                                    <button 
                                    onClick={()=>{
                                        onDelete(index)
                                    }} 
                                    className="btn btn-danger bt-sm me-3">Delete</button>
                                <button onClick={() => {
                                  onDetails(index)
                                  //console.log("indexofprop"+properties[index].id)
                                  }} className="btn btn-primary bt-sm me-3">Details</button>
                                    
                                    <button onClick={() => {
                                  onUpdate(index)
                            
                                  }} className="btn btn-dark bt-sm me-3">Edit</button>
                                
                                </td>
                            </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}
export default Properties