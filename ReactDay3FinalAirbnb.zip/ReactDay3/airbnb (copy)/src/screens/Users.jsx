import Navbar from "../components/navbar"

function Users()
{
    return(
        <div>
            <Navbar/>
            <h1 className="page-header">Users</h1>
        </div>
    )
}
export default Users