import Navbar from "../components/navbar"

function Bookings()
{
    return(
        <div>
            <Navbar/>
            <h1 className="page-header">Bookings</h1>
        </div>
    )
}
export default Bookings