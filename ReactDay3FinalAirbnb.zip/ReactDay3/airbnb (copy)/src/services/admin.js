import axios from 'axios'

export async function register(firstName,lastName,email,password){
    try{
        const body ={firstName, lastName,email,password }
        const response =await axios.post( `http://localhost:4000/admin/register`,body)
        return response.data
    }
    catch(ex)
    {
        console.log(`exception:`,ex);
    }

    return null
}


export async function login(email,password){
    try{
        const body={email,password}
        const response= await axios.post( `http://localhost:4000/admin/login`,body)
        return response.data

    }catch(ex){
        console.log(`Exception:`,ex)
    }
}

export async function abc(firstName,lastName)
{
    try{
        const body={firstName,lastName}
        const response= await axios.post(`http://localhost:4000/admin/login`,body)
        return response.data
    }
    catch(ex)
    {
        console.log(ex)
    }
}