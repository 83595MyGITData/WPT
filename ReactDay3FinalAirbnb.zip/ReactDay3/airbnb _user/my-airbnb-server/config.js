module.exports = {
  secret: 'tv5R4WfjxMjQLdTsWmWcr31ZKuqyZQod',
}
