import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css'
import { login } from "../services/admin";

export default function Login()
{
    const navigate=useNavigate()
    const[email,setEmail]=useState("");
    const[password,setPassword]=useState("");
    
    const onLogin = async () =>{
        if(email.length==0)
            {
                toast.error("enter Email")
                
            }
            else if(password.length==0)
            {
                toast.error("enter Password")
                
            }
            else{
                const result = await login (email,password)
                if(result.status=='success')
                {
                    const data=result.data
                    sessionStorage['name']=data['name']
                    sessionStorage['token']=data['token']
                    
                    console.log(data.token)

                    console.log("Login")
                    navigate('/Properties')
                
                }
                else{

                }
            }
    }

    return(
        <div>
        <h1 className="page-header">Login</h1>
        <div className="row">
         <div className="col"></div>
         <div className="col-3">
            <div className="form">
            <div className="mb-3"> 
                <label htmlFor="" className="">Email</label>
                <input onChange={(e)=>setEmail(e.target.value) }type="text" className="form-control" />
            </div>
            <div className="mb-3" >
                <label htmlFor="" className="HTMLFor">Password</label>
                <input onChange={(e)=>setPassword(e.target.value) }type="password" className="form-control" />
            </div>
            <div className="mb-3" >
                <div className="mb-3">New User Please Register <Link to='/register'>Register</Link></div>
                <button onClick={onLogin} className="btn btn-success">Login</button>
            </div>
            </div>
         </div>
         <div className="col"></div>

        </div>
        </div>
    )
}
