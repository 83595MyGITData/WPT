import Navbar from '../components/navbar2'
function Properties()
{
    return(
        <div>
            <Navbar/>
            <h1>Properties</h1>

        </div>
        
        
    )
}
export default Properties
