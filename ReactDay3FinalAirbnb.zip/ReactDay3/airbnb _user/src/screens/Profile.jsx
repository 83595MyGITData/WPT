import { useEffect, useState } from "react";
import Navbar from "../components/navbar2";
import { getProfile, updateData } from "../services/admin";

export default function Profile()
{
    const[firstName,setFirstName]=useState('');
    const[lastName,setLastName]=useState('');
    const[email,setEmail]=useState('');
    const[phoneNo,setPhoneNo]=useState('');

    const loadMyProfile = async () => {
        debugger
        const result = await getProfile ()
        if (result['status'] == 'success') {
          const { firstName, lastName, email, phoneNumber } = result.data[0]
          setFirstName(firstName)
          setLastName(lastName)
          setPhoneNo(phoneNumber)
          setEmail(email)
        } else {
          alert(result['error'])
        }
      }

      const onUpdate= async ()=>{
        if(firstName.length==0){
            alert("enter firstName")
        }
        else{
        const result= await updateData (firstName,lastName,phoneNo)

        if(result.status=='success')
        {
            alert("Successfully Updated")
        }
        else
        {
            console.log(result.error)
        }
      }
    }
    

    useEffect(()=>{
        loadMyProfile()
    },[])

    return(
        <div>
            <Navbar/>
        <h1>Profile</h1>

        <div className="row">
                <div className="col">
                    <div className="row">

                    <div className="col md-3">
                        <label htmlFor="" className="HTMLfor">First Name</label>
                        <input 
                        onChange={(e)=>setFirstName(e.target.value)}
                        type="text" 
                        value={firstName}
                        className="form-control" />
                    </div>
                    <div className="col md-3 ">
                        <label htmlFor="" className="HTMLfor">Last Name</label>
                        <input 
                        onChange={(e)=>setLastName(e.target.value)}
                        type="text" 
                        value={lastName}
                        className="form-control" />
                    </div>

                    </div>
                    <div className="row">

                    <div className="col md-3">
                        <label htmlFor="" className="HTMLfor">Email</label>
                        <input disabled
                        onChange={(e)=>setEmail(e.target.value)}
                        type="text" 
                        value={email}
                        className="form-control" />
                    </div>
                    <div className="col md-3 ">
                        <label htmlFor="" className="HTMLfor">Phone No</label>
                        <input 
                        onChange={(e)=>setPhoneNo(e.target.value)}
                        value={phoneNo}
                        type="phone" className="form-control" />
                    </div>

                    </div>

                    <button onClick={onUpdate} className="btn btn-success mt-3">update</button>


            
                 </div>
            
        </div>

        </div>
        
    )
}
