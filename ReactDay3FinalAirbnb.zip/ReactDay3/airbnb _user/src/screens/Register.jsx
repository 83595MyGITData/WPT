import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { register } from "../services/admin";

export default function Register()
{
    const[firstName,setFirstName]=useState('');
    const[lastName,setLastName]=useState('');
    const[email,setEmail]=useState('');
    const[password,setPassword]=useState('');
    const[phone,setPhone]=useState('');
    const[confirmPassword,setConfirmedPassword]=useState('');
    
    const navigate=useNavigate();
    const onRegister=async()=>{
        if(firstName.length==0)
            {
                toast.error('Enter First Name')
            }
            else if(lastName.length==0)
                {
                    console.log(setLastName)
                    toast.error('Enter Last Name')
                }
            else if(email.length==0)
                    {
                        toast.error('Enter email')
                    }
                    else if(phone.length==0)
                        {
                            toast.error('Enter phone number')
                        }
            else if(password.length==0)
            {
                toast.error('Enter password')
            }
            else if(confirmPassword.length==0)
                {
                    toast.error('Enter ConfirmPassword')

                }
            else if(password !== confirmPassword)
                {
                    toast.error('password doesnt match')
                }
            else{
                const result = await register(firstName,lastName,email,password,phone)
                if(result.status==['success'])
                    {
                    toast.success("User Registered successfully");
                    navigate('/login')
                    }
                    else{
                        console.log(result['data'])
                    }
            }
    }
    
    return(
        <div>
        <h1 className="page-header">Register</h1>

        <div className="row">
            <div className="col"></div>
            <div className="col">
            <div className="md-3">
                <label htmlFor="" className="htmlFor">First Name</label>
                <input 
                onChange={(e)=>setFirstName(e.target.value)}
                type="text" className="form-control" />
            </div>
            <div className="md-3">
                <label 
                 
                htmlFor="" className="htmlFor">Last Name</label>
                <input 
                onChange={(e)=>setLastName(e.target.value)}
                type="text" className="form-control" />
            </div>
            <div className="md-3">
                <label 
                 
                className="htmlFor">Email</label>
                <input 
                onChange={(e)=>setEmail(e.target.value)}
                type="email" className="form-control" />
            </div>

            <div className="md-3">
                <label 
                 
                className="htmlFor">Phone Number</label>
                <input 
                onChange={(e)=>setPhone(e.target.value)}
                type="phone" className="form-control" />
            </div>

            <div className="md-3">
                <label 
                 
                htmlFor="" className="htmlFor">Password</label>
                <input onChange={(e)=>setPassword(e.target.value)} type="password" className="form-control" />
            </div>
            <div className="md-3">
                <label 
                 
                htmlFor="" className="htmlFor">Confirm Password</label>
                <input onChange={(e)=>setConfirmedPassword(e.target.value)} type="text" className="form-control" />
            </div>
            
            <div className="md-3">
               <div className="mt-4"> Already registered ? <Link to = '/login'>Login</Link></div>
                <div onClick={onRegister} className="btn btn-success mt-3">Register</div>
            </div>
            </div>
            <div className="col"></div>
        </div>
        </div>
    )
}
