import { Route, Routes } from 'react-router-dom'
import Users from './screens/Users'
import Register from './screens/Register'
import Login from './screens/Login'
import Profile from './screens/Profile'
import Properties from './screens/Properties'
import { ToastContainer } from 'react-toastify'


function App(){
  return(
    <div className='container'> 
      
      <Routes>

        <Route path='/' element={<Login />}></Route>
        <Route path='/login' element={<Login />}></Route>
        <Route path ='/register' element={<Register/>}></Route>
        <Route path='/users' element={<Users />}/>
        <Route path='/profiles' element={<Profile />}/>
        <Route path='/properties' element={<Properties />}/>
      </Routes>
      <ToastContainer/>
    </div>
  )
}
export default App