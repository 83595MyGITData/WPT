import axios from 'axios'
export async function register(firstName,lastName,email,password,phone)
{
    const body={firstName,lastName,email,password,phone}
    try{
        console.log("register axios")
    const response=await axios.post(`http://localhost:4000/user/register`,body);

        console.log(response.data)
    return response.data
    }
    catch(ex)
    {
        console.log(ex)
    }
    return null

}
export async function login(email,password)
{
    try{

        const body={email,password}
        const response=await axios.post(`http://localhost:4000/user/login`,body)
        return response.data
    }catch(ex)
    {
        
    }
    return null
}

export async function getProfile() {
    try {
      const token = sessionStorage['token']
      const response = await axios.get(`http://localhost:4000/user/profile`, {
        headers: { token },
      })
      return response.data
    } catch (ex) {
      console.log(`exception: `, ex)
      return null
    }
  }

  export async function updateData(firstName,lastName,phoneNo) {
    try {
      const token = sessionStorage['token']
      const body={firstName,lastName,phoneNo}
      const response = await axios.put(`http://localhost:4000/user/profile/`,body, {
        headers: { token },
      })
      return response.data
    } catch (ex) {
      console.log(`exception: `, ex)
      return null
    }
  }