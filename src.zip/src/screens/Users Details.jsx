function UsersDetails()
{
    return(
        <div>
            <h1>UsersDetails</h1>
        </div>
    )
}
export default UsersDetails