function PropertyDetails()
{
    return(
        <div>
            <h1>PropertyDetails</h1>
        </div>
    )
}
export default PropertyDetails