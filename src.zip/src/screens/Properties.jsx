function Properties()
{
    return(
        <div>
            <h1>Properties</h1>
        </div>
    )
}
export default Properties