function Bookings()
{
    return(
        <div>
            <h1>Bookings</h1>
        </div>
    )
}
export default Bookings